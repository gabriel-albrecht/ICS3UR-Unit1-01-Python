print("Gabriel")
print("Ontario")
print("Canada")